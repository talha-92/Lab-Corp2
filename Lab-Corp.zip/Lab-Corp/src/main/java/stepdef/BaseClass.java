package stepdef;

import org.openqa.selenium.WebDriver;

public class BaseClass {
    public static WebDriver driver;
}
